import CustomLoader from './custom-loader.container';

export default CustomLoader
